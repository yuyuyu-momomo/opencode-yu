# OpenCode 摸鱼阅读

在 OpenCode 的**原生右侧栏**看本地小说，适配 OpenCode 2.1.2，兼容 1.19.x。终端需要显示会话侧栏；首页没有侧栏。

## 快速安装

[下载安装包 ZIP](https://github.com/yuyuyu-momomo/opencode-yu/raw/refs/heads/main/releases/opencode-moyu-v0.1.6.zip)，解压后运行 `bash install.sh`；Windows 原生 OpenCode 可双击 `install.cmd`。

也可直接安装仓库中的预编译版本：

```bash
git clone https://github.com/yuyuyu-momomo/opencode-yu.git
cd opencode-yu
bash install.sh
```

需要 Node.js 22+。无需 `npm install` 或编译，安装后重启 OpenCode。

## 使用

安装后重启 `opencode`，进入任意会话，右侧会出现「随手读」和原创示例小说。若侧栏关闭，按 `Ctrl+X` 后再按 `B` 显示侧栏，或在 `Ctrl+P` 中搜索 sidebar。建议终端至少 140 列、30 行（默认侧栏在大于 120 列时自动显示）。

| 按键 | 功能 |
| --- | --- |
| `Alt+M` | 立即隐藏 / 显示阅读面板 |
| `Alt+→` / `Alt+←` | 下一页 / 上一页 |
| `Alt+O` | 书架、打开本地文件 |
| `Alt+C` | 搜索、跳转章节 |
| `Alt+G` | 按百分比跳转 |
| `Ctrl+X` 后按 `J` | 打开宽高设置（也可直接点击面板按钮） |
| `Alt+D` | 删除当前资料及采集缓存，操作前确认 |

直接点击面板中的「书架」「目录」「宽度」「高度」、进度或翻页按钮即可操作；弹窗选项也可鼠标点击，无需快捷键。按钮在松开鼠标后打开菜单，避免同一次点击把新菜单关掉。「隐藏」会折叠正文，点击「显示阅读」即可恢复。`Ctrl+P` 搜索 `moyu` 或「摸鱼阅读」可以找到全部命令；`/read` 和 `/moyu` 打开书架，`/chapters` 打开目录，`/readsize` 打开宽高设置。

按 `Alt+O` 选择「打开本地文件」，输入路径，例如 `/mnt/d/books/三体.txt`。导入会生成加密副本，外部原文件保留。支持 UTF-8、带 BOM 的 UTF-16、GBK / GB18030、Markdown；单本最多 32 MiB。目前不支持 EPUB、PDF 或视频播放。

进度按文件路径分别保存在 OpenCode 自身的插件存储中，翻页及退出时自动保存。宽度或高度变化会按实际正文区域重新分页，保留阅读位置。翻页阅读不调用模型，也不把正文写入对话。

## 调整阅读区域大小

点击阅读区顶部的「宽度」或「高度」，再点击所需比例，设置即时生效并自动保存，重启后恢复。

- 宽度（OpenCode 2.x）：25%、33%、40%、50%、60%，按当前会话可用宽度计算；同时调整侧栏与正文排版，至少给主会话保留 44 列。「默认宽度」恢复宿主原有宽度，隐藏阅读时也会恢复。
- 高度：25%、50%、75%、100%，另有自定义 10–100% 和「自动高度」。页码、翻页和操作提示随正文区域一起移动，末页也保留相同高度。

高度比例按侧栏预留标题和操作栏后的可用正文高度计算，正文最少保留 4 行。宽度至少保留 36 列，过小的终端会限制可用尺寸。1.19.x 保留原生侧栏宽度，支持点击调高、目录和翻页。快捷键 `Ctrl+X` 后按 `J` 与 `/readsize` 仍可打开设置。

## 让当前模型采集小说

OpenCode 2.x 中，在输入框提交：

```text
/moyu 忘语的凡人修仙传，先采集20章
```

或输入 `/moyu` 打开书架，选择「让当前模型采集小说…」，填写书名、作者或目录链接。输入命令后若先出现补全结果，按 Enter 补全，再按 Enter 提交。

聊天区只显示一句 `采集小说：你输入的书名或要求`。HTTP 采集方式、工具调用及失败处理规则放在后台模型上下文中，不再作为长段用户消息显示。

插件会沿用当前选中的模型，每次采集创建一个独立的普通会话，不携带编程对话历史，避免先触发旧会话压缩。原会话保留，可从会话列表返回。模型查找来源、核对目录，再分批存进加密书架，不需要另配 API 密钥。采集进度和错误在 OpenCode 对话中显示；完成后输入 `/moyu` 选择小说阅读。目录默认只返回 10 章，正文在插件内部提取并分批加密入库，交给右侧阅读器显示。默认先采集 20 章，也可在要求中指定数量。请在可联网并允许工具执行的 agent 中使用；访问授权沿用 OpenCode 的现有设置。

采集任务限定为纯 HTTP/HTTPS：目录和正文由插件直接下载、解析并加密入库。`/moyu` 在后台注入的模型规则明确禁止浏览器、无头浏览器、Playwright、Selenium、CDP、浏览器 MCP，以及依赖浏览器的搜索技能。只有书名时使用内置 `moyu_search` 调用已有的 HTTP 搜索接口；搜索接口不可用时报告缺少目录链接，不安装浏览器或搜索环境。目录为空、需要 JavaScript、登录或验证码时停止该来源，不回退浏览器、不加载整页 HTML 到模型上下文。

1.19.x 仍支持采集工具，在普通对话中向模型提出同样要求即可。

2.x 内置 `moyu_search`，复用 OpenCode 的 HTTP 搜索接口，最多返回 5 条标题、链接和短摘要，省去网页全文。默认使用 Exa，可通过插件选项 `searchProvider` 指定 `exa`、`tavily`、`parallel` 或 `firecrawl`。

模型可调用 `moyu_search` 查找来源、`moyu_sources` 查看来源能力、`moyu_catalog` 查看目录、`moyu_import` 分批采集、`moyu_library` 查看资源、`moyu_delete` 删除用户指定的资源。相同 URL 重复采集会续接未完成章节，成功章节不重复下载；抓到的书按 `Alt+O` 即可打开。

默认适配器支持可直接访问的 HTML 目录和正文页，可指定 `catalogSelector` / `contentSelector` 适配网站。不会执行页面脚本；登录、验证码、动态渲染页面和分页目录需要专用来源适配器。访问来源沿用 OpenCode 的 `webfetch` 权限。工具返回进度和路径摘要，正文留在本地资料库。

## 加密与删除

导入和采集的正文、章节缓存、任务记录、资源索引均以 AES-256-GCM 加密后落盘，文件名使用资源 ID。密钥独立保存在安装目录的 `keys/library.key`（Linux 权限 `0600`），默认书架在 `books/`。阅读时在内存中解密。附带的原创示例源文件为普通 TXT。

`Alt+D` 或点击「删除」可清理当前资料的加密正文、索引和续采缓存。外部原文件保留。删除属于文件系统中的逻辑删除。密钥由本机账号管理；这不是需要密码解锁的保险箱，也不防拥有本机账号权限的程序。迁移资料库时需要单独备份密钥，丢失密钥无法解密已有内容。卸载插件默认保留资料及密钥。

## 安装与卸载

解压安装包后，运行安装脚本即可。需要 Node.js 22+ 和 OpenCode 2.1.2 / 1.19.x，**不需要 `npm install`、编译或手改配置**。

```bash
bash install.sh
# 重启 opencode
```

Windows 原生 OpenCode 可双击 `install.cmd`；WSL 中使用 OpenCode 时，请在 WSL 运行 `bash install.sh`。安装器把插件及示例复制到配置目录内的 `extensions/opencode-moyu/`，自动识别版本：2.x 向 `opencode.json` 的 `plugins` 注册包目录，自动加载服务端和 `./tui` 双入口；若已有 `cli.json` / `cli.jsonc`，同步注册并迁移旧的文件入口；1.19.x 向 `tui.json` 和 `opencode.json` 的 `plugin` 注册对应入口（均支持已有 JSONC 文件）。完成后可以删除解压目录。

支持 `XDG_CONFIG_HOME` 和 `OPENCODE_CONFIG_DIR`。已有配置先备份，JSONC 注释、其他插件和模型 provider 设置保留；重复运行可更新插件。

```bash
bash install.sh --remove
# 重启 opencode；小说和阅读进度不会删除
```

如果已删除解压目录，可使用安装结束时显示的卸载命令。默认路径如下：

```bash
node ~/.config/opencode/extensions/opencode-moyu/dist/install.mjs --remove
```

只装到某个项目，或先查看将写入的配置：

```bash
bash install.sh --config-dir /path/to/project/.opencode
bash install.sh --dry-run
```

可在配置的插件选项中指定书架、启动文件和每页最大行数：

```json
{
  "plugins": [
    {
      "package": "file:///home/your-user/.config/opencode/extensions/opencode-moyu",
      "options": {
        "booksDir": "/mnt/d/books",
        "rows": 18
      }
    }
  ]
}
```

上例适用于 2.x 的 `opencode.json`；1.19.x 使用 `tui.json` 中的 `plugin: [["file:///.../dist/tui.js", { ... }]]`。若无法自动识别版本，可运行 `bash install.sh --opencode-major 2`（或 `1`）。升级 OpenCode 大版本后重新运行安装脚本。

可选 `file` 指定启动小说路径。快捷键可在 `cli.json`（1.19.x 为 `tui.json`）的 `keybinds` 中按命令名覆盖，如 `"moyu.toggle": "alt+m"`。少数终端会拦截 Alt+方向键，可使用点击或命令面板翻页。

## 开发与验证

架构与来源接入说明见 [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)。当前内置小说来源和阅读器；资源契约已预留视频、音频、图片及数据集类型。

```bash
npm ci --ignore-scripts
npm run build
npm run typecheck
npm test
```

构建将阅读逻辑和文本排版依赖打包，Solid / OpenTUI 及 2.x 插件 API 由 OpenCode 宿主提供。2.x 使用 [CLI 插件 API](https://opencode.ai/v2/docs/build/plugins/cli/) 的 `sidebar.content` 插槽；1.19.x 使用 `sidebar_content` 插槽。两代入口共享阅读、资料库及来源服务；内置示例为原创短篇。
